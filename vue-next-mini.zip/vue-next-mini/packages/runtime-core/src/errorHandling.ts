
    
    
      <!-- <view class="accountInfo flex-center-between">
          <view class="item" bindtap="jumpToPages" data-token="balance">
            <view class="accountNum {{otherData.isLogin?'accountNum-islogin':''}}" style="font-size:{{(init.showSeviceCharge&&init.thirdBalanceAccount ?(init.myAccount.length>=10?'20rpx':(init.myAccount.length == 9 ? '25rpx':(init.myAccount.length == 8 ? '30rpx':'32rpx'))):'32rpx')}}">{{init.myAccount}}</view>
            <view class="accountName">可用余额</view>
            <block wx:if="{{init.creditLimit>0||init.expireCardNum>0}}">
              <view class="tips" wx:if="{{init.creditLimit>0}}">信用{{init.creditLimit}}元</view>
              <view class="tips" wx:else></view>
            </block>
            <view class="overdue"></view>
          </view>
          <view class="item" bindtap="jumpToPages" data-token="cards">
            <view class="accountNum {{otherData.isLogin?'accountNum-islogin':''}}" style="font-size:{{(init.showSeviceCharge&&init.thirdBalanceAccount ?(init.cardNum.length>=10?'20rpx':(init.cardNum.length == 9 ? '25rpx':(init.cardNum.length == 8 ? '30rpx':'32rpx'))):'32rpx')}}">{{init.cardNum}}</view>
            <view class="accountName">卡券</view>
            <block wx:if="{{init.creditLimit>0||init.expireCardNum>0}}">
              <view class="tips" wx:if="{{init.expireCardNum>0}}">{{init.expireCardNum}}张即将到期</view>
              <view class="tips" wx:else></view>
            </block>
            <view class="overdue"></view>
          </view>
          <view class="item" bindtap="jumpToPages" data-token="serviceCharge" wx:if="{{init.showSeviceCharge}}">
            <view class="accountNum {{otherData.isLogin?'accountNum-islogin':''}}" style="font-size:{{!init.isPower?'34rpx':(init.showSeviceCharge&&init.thirdBalanceAccount?(init.powerLeftLength.length>=10?'20rpx':(init.powerLeftLength.length == 9 ? '25rpx':(init.powerLeftLength.length == 8? '30rpx':'32rpx'))):'32rpx')}};{{(init.powerLeftLength.length>=4)&&common.electricityObj&&common.electricityObj.replaceUnit=='千瓦时'&&init.isPower?'line-height:unset':''}}"><text>{{init.powerLeft}}</text><text wx:if="{{init.isPower}}" style="font-size:{{(init.showSeviceCharge&&init.thirdBalanceAccount?(init.powerLeftLength.length>=10?'10rpx':(init.powerLeftLength.length == 9 ?'12rpx':(init.powerLeftLength.length == 8 ? '15rpx':'20rpx'))):'20rpx')}};{{(init.powerLeftLength.length>=4)&&common.electricityObj&&common.electricityObj.replaceUnit=='千瓦时'?'display:inline-block':''}}">{{kwhcomm.replaceElectricityUnit('度')}}</text></view>
            <view class="accountName">套餐</view>
            <view class="tips" wx:if="{{init.creditLimit>0||init.expireCardNum>0}}"></view>
            <view class="overdue"></view>
          </view>
          <view class="item" catchtap="jumpToPages" data-token="integral">
            <view class="accountNum {{otherData.isLogin?'accountNum-islogin':''}}" style="font-size:{{(init.showSeviceCharge&&init.thirdBalanceAccount ?(init.score.length>=10?'20rpx':(init.score.length == 9 ? '25rpx':(init.score.length == 8 ? '28rpx':'32rpx'))):'32rpx')}}">{{init.score}}</view>
            <view class="accountName">积分</view>
            <block wx:if="{{init.creditLimit>0||init.expireCardNum>0}}">
              <view class="tips" wx:if="{{init.expireScore>0&&expiration>0&&expiration<=init.dueDays}}">{{init.expireScore}}积分即将到期</view>
              <view class="tips" wx:else></view>
            </block>
            <view class="overdue"></view>
          </view>
          <view class="item" bindtap="jumpToPages" data-token="thirdAccount" wx:if="{{init.thirdBalanceAccount.length>0}}">
            <view class="accountNum {{otherData.isLogin?'accountNum-islogin':''}}" style="font-size:{{(init.showSeviceCharge&&init.thirdBalanceAccount&& init.thirdBalanceAccount.length == 1?(init.thirdBalanceAccount[0].balance.length>=10?'20rpx':(init.thirdBalanceAccount[0].balance.length == 9 ? '25rpx':(init.thirdBalanceAccount[0].balance.length == 8 ? '30rpx':'40rpx'))):'40rpx')}}">
              <view wx:if="{{init.thirdBalanceAccount && init.thirdBalanceAccount.length > 1}}">
                <text>{{init.thirdBalanceAccount.length}}</text><text style="font-size:24rpx">家</text>
              </view>
              <text wx:else>{{init.thirdBalanceAccount[0].balance}}</text>
            </view>
            <view class="accountName">第三方账户</view>
            <view class="tips" wx:if="{{init.creditLimit>0||init.expireCardNum>0}}"></view>
            <view class="overdue"></view>
          </view>
        </view> -->